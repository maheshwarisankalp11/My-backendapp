import React, { Component } from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'

export default class Dashboard extends Component {
    render() {
        let userName=localStorage.getItem("username");
        return (
    <>
    <center><h1>Welcome {userName} </h1></center>
    
    <center><h1>Dashboard</h1></center>
    
    <button type="submit" className="dashboard"><Link className="nav-link" to ={'/MyDetails'}> My Details Section</Link></button>
    
    <button type="submit" className="dashboard"><Link  className="nav-link" to={'/MyManager'}>My Manager Details</Link></button>
    
    {/* <button type="submit" className="dashboard"><Link className="nav-link" to={'/ApplyLeave'}>Apply leave</Link></button> */}
    
    {/* <button type="submit" className="dashboard"><Link  className="nav-link" to={'/Approve_Deny_Leave'}>Approve Deny Leave</Link></button> */}
    
    <button type="submit" className="dashboard"><Link className="nav-link" to ={'/MyPreviousLeaves'}> My Leave Applications Section</Link></button>
    
    {/* <button type="submit" className="dashboard"><Link className="nav-link" to ={' /Pending_Leaves'}>My Reporting Employees' Pending Leave Application</Link></button> */}
    
    </>
        )
    }
}
